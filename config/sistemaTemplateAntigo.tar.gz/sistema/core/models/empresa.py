from django.db import models

from core.models.base.time_stampable import Timestampable


class Empresa(Timestampable):
    class Meta:
        verbose_name_plural = 'Empresa'

    nome_razao_social = models.CharField('Nome/Razão Social', max_length=160)

    def __str__(self):
        return self.nome_razao_social.upper()
